<?php
include 'database.php';
if(isset($_POST["firstname"], $_POST["lastname"],$_POST["designation"],$_POST["contactno"],$_POST["emailid"],$_POST["useraddress"]))
{
 $firstname = mysqli_real_escape_string($conn, $_POST["firstname"]);
 $lastname = mysqli_real_escape_string($conn, $_POST["lastname"]);
 $designation = mysqli_real_escape_string($conn, $_POST["designation"]);
 $contactno = mysqli_real_escape_string($conn, $_POST["contactno"]);
 $emailid = mysqli_real_escape_string($conn, $_POST["emailid"]);
 $useraddress = mysqli_real_escape_string($conn, $_POST["useraddress"]);
   function rand_string( $length ) {

       $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
       return substr(str_shuffle($chars),0,$length);

      }

$rand_pwd=rand_string(8);
 

 

 $query="select max(id) as id  from users order by id desc";
			
            $checkadmin=mysqli_query($conn,$query);
			while($rows = mysqli_fetch_array($checkadmin))
          {
               $id = $rows['id']+1;
            
              }

 $query1= "INSERT INTO user_information(user_id,firstname,lastname,designation,contactno,emailid,useraddress) VALUES('$id','$firstname','$lastname','$designation','$contactno','$emailid','$useraddress')";
 
  $query_insert = "INSERT INTO users(fname,lname,email,role,password,contactno) VALUES('$firstname','$lastname','$emailid',2,'$rand_pwd','$contactno')";
 mysqli_query($conn, $query_insert);
 if(mysqli_query($conn, $query1))
 {
  echo 'Data Inserted';
 }
 

 
//mail function

// Check whether submitted data is not empty 
//mail function//

//if(!empty($emailid) && !empty($firstname)){ 
         
    //if(filter_var($emailid, FILTER_VALIDATE_EMAIL) === false){ 
       // $statusMsg = 'Please enter a valid email.'; 
    //}else{ 
        //$emailSubject = 'Your information enetered in our organization profile '.$firstname; 
        //$message="information recorded successfully";
        //$toEmail="org@gmail.com";
        //$htmlContent = '<h2>Contact Request Submitted</h2> 
            //<h4>Name</h4><p>'.$firstname.'</p> 
            //<h4>Email</h4><p>'.$emailid.'</p> 
            //<h4>Message</h4><p>'.$message.'</p>'; 
         
        // Set content-type header for sending HTML email 
       // $headers = "MIME-Version: 1.0" . "\r\n"; 
        //$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n"; 
         
        // Additional headers 
        //$headers .= 'From: '.$firstname.'<'.$emailid.'>'. "\r\n"; 
         
        // Send email 
        //$sendEmail = mail($toEmail, $emailSubject, $htmlContent, $headers); 
        //if($sendEmail){ 
            //$status = 1; 
           // $statusMsg = 'Thanks! Your contact request has been submitted successfully.'; 
        //}else{ 
           // $statusMsg = 'Failed! Your contact request submission failed, please try again.'; 
        //} 
    //} 
//}else{ 
    //$statusMsg = 'Please fill in all the mandatory fields.'; 
//} 

}
?>