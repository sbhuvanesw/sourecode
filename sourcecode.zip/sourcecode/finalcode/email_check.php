<?php
include 'database.php';

$sql = "SELECT email FROM users WHERE  	email= " .$_GET['email'];
$select = mysqli_query($con, $sql);
$row = mysqli_fetch_array($select);
$email=$row['email'];
if ( email_exists($email) ) {
    $response->result = true;
}
else {
    $response->result = false;
}

// echo json
echo json_encode($response);
?>
