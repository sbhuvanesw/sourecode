<?php
	include 'database.php';
	session_start();
	if($_POST['type']==1){
		$fname=$_POST['fname'];
		$lname=$_POST['lname'];
		$email=$_POST['email'];
		$phone=$_POST['phone'];
		$role=$_POST['role'];
		$password=$_POST['password'];
		$useraddress=$_POST['useraddress'];
		$hash_password = password_hash($password,PASSWORD_DEFAULT); 
		$duplicate=mysqli_query($conn,"select * from users where email='$email'");
		
		if (mysqli_num_rows($duplicate)>0)
		{
			echo json_encode(array("statusCode"=>201));
			
		}
		else{
			
			$sql = "INSERT INTO `users`( `fname`,`lname`, `email`, `role`, `password`,`contactno`,`useraddress`) 
			VALUES ('$fname','$lname','$email','$role', '$hash_password','$phone','$useraddress')";
			$query="select max(id) as id  from users order by id desc";
			
            $checkadmin=mysqli_query($conn,$query);
			while($rows = mysqli_fetch_array($checkadmin))
          {
               $id = $rows['id']+1;
            
              }
			
         $query1= "INSERT INTO user_information(user_id,firstname,lastname,designation,role,contactno,emailid,useraddress) VALUES('$id','$fname','$lname','','$role','$phone','$email','$useraddress')";
		 $exe=mysqli_query($conn, $query1);

           
		 if (mysqli_query($conn, $sql)) {
				echo json_encode(array("statusCode"=>200));
			} 
			else {
				echo json_encode(array("statusCode"=>201));
							}
		}
		mysqli_close($conn);
	}
	if($_POST['type']==2){
		$email=$_POST['email'];
		$password=$_POST['password'];
		$check_pwd=mysqli_query($conn,"select password  from users where email='$email'");
		$result=mysqli_fetch_array($check_pwd);
		$hash_pwd=$result['password'];
		$verify = password_verify($password, $hash_pwd); 
		
		$check=mysqli_query($conn,"select * from users where email='$email'");
		if ((mysqli_num_rows($check)>0) && $verify>0)
		{
			$_SESSION['email']=$email;
			$checkadmin=mysqli_query($conn,"select * from users where email='$email' and  role='1'");
			if (mysqli_num_rows($checkadmin)>0)
			 {
			echo json_encode(array("statusCode"=>200,"page" =>"home.php"));
			 }
			 else{
				echo json_encode(array("statusCode"=>200,"page" =>"home.php"));
			}
		}
		
		else{
			echo json_encode(array("statusCode"=>201));
		}
		mysqli_close($conn);
	}

	
	
?>
  