<?php 
include 'database.php'; 
 if(isset($_REQUEST["user_id"]))  
 {  
      $output = '';  
      $id=(int)$_REQUEST["user_id"];
      
 
 ?>
	<div class="table-responsive">  
        <form name="updateform" method="post" action="updateuserdata.php">
		<table class="table table-bordered">
			<?php
               $query = "SELECT * FROM user_information WHERE id = '".$id."'";  
               $result = mysqli_query($conn, $query);  
               $nums=mysqli_num_rows($result);
			if($nums>0)
			{
				while($rows = mysqli_fetch_array($result))
                {
				?>
				<tr>  
                     <td width="40%"><label>First Name</label></td>  
                     <td width="60%"><input type="hidden" name="id" id="id" value="<?=$rows["id"];?>">
                        <input type="text" name="firstname" id="firstname" value="<?=$rows["firstname"];?>"></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Last Name</label></td>  
                     <td width="60%"><input type="text" name="lastname" id="lastname" value="<?=$rows["lastname"];?>"></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Role</label></td>  
                     <td width="60%"><input type="text" name="designation" id="designation" value="<?=$rows["designation"];?>"></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Mobileno</label></td>  
                     <td width="60%"><input type="text" name="contactno"  id="contactno" value="<?=$rows["contactno"];?>"></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Emailid</label></td>  
                     <td width="60%"><input type="text" name="emailid"  id="emailid" value="<?=$rows["emailid"];?>"></td>  
                </tr> 
                <tr>  
                     <td width="40%"><label>Address</label></td>  
                     <td width="60%"><textarea name="useraddress" id="useraddress" cols="30" rows="10"><?=$rows["useraddress"];?></textarea></td>  
                </tr> 
                
				<?php
			}}
				?> 
			
		</table>
        <input type="submit"name="updatedata" class="updatedata" value="submit">
        </form>
	</div>
<?php } 



?>

