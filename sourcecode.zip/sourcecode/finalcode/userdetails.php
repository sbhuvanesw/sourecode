<?php 
include 'database.php'; 
 if(isset($_REQUEST["user_id"]))  
 {  
      $output = '';  
      $id=(int)$_REQUEST["user_id"];
      $query = "SELECT * FROM user_information WHERE id = '".$id."'";  
      $result = mysqli_query($conn, $query);  
	 	  $nums=mysqli_num_rows($result);
 
 ?>
	<div class="table-responsive">  
		<table class="table table-bordered">
			<?php
			if($nums>0)
			{
				$rows = mysqli_fetch_array($result);
				?>
				<tr>  
                     <td width="40%"><label>First Name</label></td>  
                     <td width="60%"><?=$rows["firstname"];?></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Last Name</label></td>  
                     <td width="60%"><?=$rows["lastname"];?></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>designation</label></td>  
                     <td width="60%"><?=$rows["designation"];?></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Mobileno</label></td>  
                     <td width="60%"><?=$rows["contactno"];?></td>  
                </tr>  
                <tr>  
                     <td width="40%"><label>Emailid</label></td>  
                     <td width="60%"><?=$rows["emailid"];?></td>  
                </tr> 
                <tr>  
                     <td width="40%"><label>Address</label></td>  
                     <td width="60%"><?=$rows["useraddress"];?></td>  
                </tr> 
                
				<?php
			}
				?> 
			
		</table>
	</div>
<?php } 


?>