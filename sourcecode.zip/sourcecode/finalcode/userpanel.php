<?php 
session_start();
if(!isset($_SESSION["email"])){
  header("location:index.php");
}

include 'database.php';
echo  $emailid=$_SESSION["email"];

  $query = "SELECT * FROM  user_information where emailid='$emailid'";  
 $result = mysqli_query($conn, $query); 
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>userprofile</title>  
           <script src="js/jquery-min.js"></script>  
           <link rel="stylesheet" href="css/bootstrap.min.css" />  
           <script src="js/bootstrap.min.js"></script>  
      </head>  
      <body>  
           <br /><br />  
           <div class="container" style="width:700px;">  
                <h3 align="center">My Profile Page</h3>  
                <br />  

                <div align="right">
                <button type="button" name="add" id="back" class="btn btn-info"><a href="home.php">Back</a></button>
   <button type="button" name="add" id="back" class="btn btn-info"><a href="logout.php">logout</a></button>
</div>
<br><br>
                <div class="table-responsive">  
                     <table class="table table-bordered">  
                          <tr>  
                          <th>Frist Name</th>
       <th>Last Name</th>
       <th>Role</th>
       <th>Contactno</th>
       <th>Emailid</th>
       <th>Address</th> 
                          </tr>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                          ?>  
                          <tr>  
                               <td><?php echo $row["firstname"]; ?></td>  
                               <td><?php echo $row["lastname"]; ?></td> 
                               <td><?php echo $row["designation"]; ?></td> 
                               <td><?php echo $row["contactno"]; ?></td> 
                               <td><?php echo $row["emailid"]; ?></td> 
                               <td><?php echo $row["useraddress"]; ?></td> 
                               <td><input type="button" name="view" value="view" id="<?php echo $row["id"]; ?>" class="btn btn-info btn-xs view_data" /></td>  
                          </tr>  
                          <?php  
                          }  
                          ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  
 <div id="dataModal" class="modal fade">  
      <div class="modal-dialog">  
           <div class="modal-content">  
                <div class="modal-header">  
                     <button type="button" class="close" data-dismiss="modal">&times;</button>  
                     <h4 class="modal-title">User Details</h4>  
                </div>  
                <div class="modal-body" id="User_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>  
                </div>  
           </div>  
      </div>  
 </div>  
 <script>  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var user_id = $(this).attr("id");  
           $.ajax({  
                url:"userdetails.php",  
                method:"post",  
                data:{user_id:user_id},  
                success:function(data){  
                     $('#User_detail').html(data);  
                     $('#dataModal').modal("show");  
                }  
           });  
      });  
 });  
 </script>
