<?php
include 'database.php';
if(isset($_POST["id"]))
{
 $query = "UPDATE user_information SET delete_status='2' WHERE id = '".$_POST["id"]."'";
 if(mysqli_query($conn, $query))
 {
  echo 'Data Deleted';
 }
}
?>