<?php
include 'database.php';

 $id=$_POST['id']; 
 $firstname = $_POST['firstname'];
$lastname = $_POST['lastname'];
$designation = $_POST['designation'];
$contactno = $_POST['contactno'];
$emailid = $_POST['emailid'];
$useraddress =$_POST['useraddress'];
//echo "UPDATE user_information SET firstname='$firstname', lastname='$lastname',designation='$designation', contactno ='$contactno', emailid='$emailid',useraddress='$useraddress' where id='$id'"; exit;
 $query = "UPDATE user_information SET firstname='$firstname', lastname='$lastname',designation='$designation', contactno ='$contactno', emailid='$emailid',useraddress='$useraddress' where id='$id'";
 
 $query_users = "UPDATE users SET fname='$firstname', lname='$lastname',contactno ='$contactno',email='$emailid' where id='$id'";
 mysqli_query($conn, $query_users);
 if(mysqli_query($conn, $query))
 {
  echo "<script>window.location.href = 'welcome.php'; </script>";
 
 }
 
 
 
    
?>