<?php
//fetch.php
include 'database.php';
$columns = array('firstname', 'lastname','role','contactno','emailid','useraddress');

$query = "SELECT * FROM  user_information ";

if(isset($_POST["search"]["value"]))
{
 $query .= '
 WHERE firstname LIKE "%'.$_POST["search"]["value"].'%" 
 OR lastname LIKE "%'.$_POST["search"]["value"].'%" 
 OR designation LIKE "%'.$_POST["search"]["value"].'%" 
 OR contactno LIKE "%'.$_POST["search"]["value"].'%" 
 OR emailid  LIKE "%'.$_POST["search"]["value"].'%" 
 OR useraddress LIKE "%'.$_POST["search"]["value"].'%" 
 ';
}

if(isset($_POST["order"]))
{
 $query .= 'ORDER BY '.$columns[$_POST['order']['0']['column']].' '.$_POST['order']['0']['dir'].' 
 ';
}
else
{
 $query .= 'ORDER BY id DESC ';
}

$query1 = '';

if($_POST["length"] != -1)
{
 $query1 = 'LIMIT ' . $_POST['start'] . ', ' . $_POST['length'];
}

//$number_filter_row = mysqli_num_rows(mysqli_query($conn, $query));
$result = mysqli_query($conn, $query) or die(mysqli_error($conn));
$number_filter_row = mysqli_num_rows($result);

$result = mysqli_query($conn, $query . $query1);



$data = array();

while($row = mysqli_fetch_array($result))
{
 $sub_array = array();
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["id"].'" data-column="firstname">' . $row["firstname"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["id"].'" data-column="lastname">' . $row["lastname"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["id"].'" data-column="designation">' . $row["designation"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["id"].'" data-column="contactno">' . $row["contactno"] . '</div>';
 $sub_array[] = '<div contenteditable  data-id="'.$row["id"].'">' . $row["emailid"] . '</div>';
 $sub_array[] = '<div contenteditable class="update" data-id="'.$row["id"].'" data-column="useraddress">' . $row["useraddress"] . '</div>';
 $sub_array[] = '<input type="button" name="view" value="view" id="'.$row["id"].'" class="btn btn-info btn-xs view_data" /></button>';
 if($row['delete_status']==2)
 {
 $sub_array[] = '<button type="button" name="delete" style="background-color: black; border-color: black;" class="btn btn-danger btn-xs" id="'.$row["id"].'">Disble</button>';
 }
 else{
 $sub_array[] = '<button style="background-color: green;" type="button" name="delete" class="btn btn-danger btn-xs edit_data" id="'.$row["id"].'">Edit</button>';
}

 if($row['delete_status']==1)
 {
 $sub_array[] = '<button type="button" name="delete" class="btn btn-danger btn-xs delete" id="'.$row["id"].'">Delete</button>';
 }
 else{
    $sub_array[] = '<button type="button" name="delete" style="background-color: black; border-color: black;" class="btn btn-danger btn-xs" id="'.$row["id"].'">Deleted</button>';

 }
 
 $data[] = $sub_array;
}

function get_all_data($conn)
{
 $query = "SELECT * FROM user_information where delete_status='1'";
 $result = mysqli_query($conn, $query);
 return mysqli_num_rows($result);
}

$output = array(
 "draw"    => intval($_POST["draw"]),
 "recordsTotal"  =>  get_all_data($conn),
 "recordsFiltered" => $number_filter_row,
 "data"    => $data
);

echo json_encode($output);

?>

